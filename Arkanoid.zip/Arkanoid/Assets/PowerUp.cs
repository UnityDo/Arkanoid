﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class PowerUp : MonoBehaviour
{
   UnityEvent OnRecoge;
    // Start is called before the first frame update
    void Start()
    {
        if (OnRecoge == null)
        {
            OnRecoge = new UnityEvent();
        }
           
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.CompareTag("Player"))
        {
            OnRecoge.AddListener(otro.GetComponent<Pala>().RecogePowerUp);
            OnRecoge.Invoke();
            Destroy(gameObject);
        }
    }
}
