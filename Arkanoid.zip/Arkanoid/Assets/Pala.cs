﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(Rigidbody2D))]
public class Pala : MonoBehaviour
{
    Rigidbody2D rb;
    float x;
    public Configuracion configuracion;
   public GameObject misil;
    int cargadorMisiles = 10;
    int misilesActuales;
    

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        x = Input.GetAxisRaw("Horizontal");
    }
    private void FixedUpdate()
    {
        rb.velocity = new Vector2(x, 0) * configuracion.velocidadPala;
    }
    public void RecogePowerUp()
    {
        print("Power up");
        misilesActuales = cargadorMisiles;
        InvokeRepeating("LanzaMisil", 0, 2);

    }
    void LanzaMisil()
    {
        
        Vector2 posAux = transform.position;
        posAux.y += 1;
        GameObject clonMisil = Instantiate(misil, posAux, Quaternion.identity) as GameObject;
       
        misilesActuales--;
        if (misilesActuales==0)
        {
            CancelInvoke();
        }
    }
}
