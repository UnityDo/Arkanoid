﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName ="Configura",menuName ="Configuracion")]
public class Configuracion : ScriptableObject
{
    public float velocidadPala;
    public float velocidadBola;
    public int puntosXLadrillo;
    public int vidasIniciales;
}
