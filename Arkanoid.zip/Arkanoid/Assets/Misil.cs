﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent (typeof(Rigidbody2D))]
public class Misil : MonoBehaviour
{
    Rigidbody2D rb;
    public GameObject explosion;
    Control controlJuego;
    // Start is called before the first frame update
    void Start()
    {
        controlJuego = GameObject.FindObjectOfType<Control>();
        rb = GetComponent<Rigidbody2D>();
        rb.AddForce(new Vector2(0, 2), ForceMode2D.Impulse);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter2D(Collision2D otro)
    {
        if (otro.collider.CompareTag("Ladrillo"))
        {
            Destroy(otro.gameObject);
            //Destruye ladrillo
            //Quita ladrillo del contador
            controlJuego.RestaLadrillos();
            Instantiate(explosion, otro.GetContact(0).point, Quaternion.identity);

        }
        Destroy(gameObject);
    }
}
