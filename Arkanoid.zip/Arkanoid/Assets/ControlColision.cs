﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ControlColision : MonoBehaviour
{
    Rigidbody2D rb;
    public Configuracion configuracion;
   public UnityEvent OnDestruye;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter2D(Collision2D otro)
    {
        if (otro.collider.CompareTag("Player"))
        {
            float x = Golepa_En(transform.position, otro.transform.position, otro.collider.bounds.size.x);
            //El rebote basado en donde golpea
            Vector2 rebote = new Vector2(x, 1).normalized;
            rb.velocity = rebote * configuracion.velocidadBola;
        }else if (otro.collider.CompareTag("Ladrillo"))
        {
            OnDestruye.Invoke();
            Destroy(otro.gameObject);
        }
        
    }
    float Golepa_En(Vector2 ballPos, Vector2 palaPos,
       float anchuraPala)
    {
        // ascii art:
        // 1  0   -1
       /// ========
        
        return (ballPos.x - palaPos.x) / anchuraPala;
    }
}
