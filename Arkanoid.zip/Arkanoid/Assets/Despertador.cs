﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Despertador : MonoBehaviour
{
    public UnityEvent OnAlarma;
    int hora;
    bool sonado = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        hora = System.DateTime.Now.Hour;
        if (hora == 9&&!sonado)
        {
            SuenaDesperador();
        }
    }
    void SuenaDesperador()
    {
        Debug.Log("Suena despertador");
        OnAlarma.Invoke();
        sonado = true;
    }
}
