﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using TMPro;
using UnityEngine.UI;


public class Control : MonoBehaviour
{
    [HideInInspector]
    public GameObject bola;
    [HideInInspector]
    public GameObject pala;
    Rigidbody2D rbBola;
    public Configuracion configuracion;
    bool disparado = false;

    public Transform pos_bola;
    public TextMeshProUGUI puntosText;
    int puntos;
    public Image[] VidasImagen;
    int vidasActual;
    public Panel GameOverP, VictoriaP;
    //Contar ladrillos
    [SerializeField]
    int numerodeLadrillos;
    int nivel = 0;
    public int Puntos { 
        get { 
            return puntos;
        }
        set {
            puntos = value;
            puntosText.text = puntos.ToString("000000");
        }
    }

    //Que cambiamos en el siguiente nivel
    //Fondo
    public Sprite[] Fondos;
    public GameObject[] Niveles;
    public SpriteRenderer fondo;
    public Transform posicionNivel;

   Vector3 posicionInicialPala, posicionIncialBola;
    // Start is called before the first frame update
    void Start()
    {
        vidasActual = configuracion.vidasIniciales;
        bola = GameObject.FindGameObjectWithTag("Bola");
        pala = GameObject.FindGameObjectWithTag("Player");
        posicionInicialPala = pala.transform.position;
        posicionIncialBola = bola.transform.position;

        IniciarNivel(nivel);
        //Recoger un rigibody desde otro objeto

        //Intentar recoger el rigibody de bola

    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (!disparado)
            {
                LanzaBola();
            }
            
        }
    }

    private void LanzaBola()
    {
        disparado = true;
        if (bola.TryGetComponent<Rigidbody2D>(out rbBola))
        {
            //Velocidad continua
            //rbBola.velocity = Vector2.up* velocidadBola;
            //Desemparentar
            rbBola.transform.parent = null;
            rbBola.bodyType = RigidbodyType2D.Dynamic;
            rbBola.AddForce(Vector2.up * configuracion.velocidadBola, ForceMode2D.Impulse);
        }
        else
        {
            Debug.Log("Falta el rb");
            throw new ArgumentNullException("Rb es nulo");
        }
    }
    public void EntraEnZona()
    {
        //quitar vida
        //volver a colocar la bola
        //Emparenta con la pala
        rbBola.transform.parent = pala.transform;
        rbBola.bodyType = RigidbodyType2D.Kinematic;
        bola.transform.position = pos_bola.position;
        rbBola.velocity = Vector2.zero;
        //permitir volver a lanzar
        disparado = false;
    }
    public void SumaPuntos()
    {

        Puntos += configuracion.puntosXLadrillo;

    }
    void CambiaVidas()
    {
        //Quitar todas y activar solo las que tengas
        foreach(Image i in VidasImagen)
        {
            i.enabled = false;
        }
        //Activo
        for (int i = 0; i < vidasActual; i++)
        {
            VidasImagen[i].enabled = true;
        }
    }
    public void QuitaVida()
    {
        vidasActual--;
        //Verificar GameOver
        CambiaVidas();
        if (vidasActual == 0)
        {
            GameOver();
        }
    }
    void GameOver()
    {
        GameOverP.Abrir();
       
    }
    public void RestaLadrillos()
    {
        numerodeLadrillos--;
        if (numerodeLadrillos == 0)
        {
            //Victoria
            print("Termina el juego");
            //pasas al siguiente nivel
            Victoria();
        }
    }
    void Victoria()
    {
        //Esta entre 0 y 1
        Time.timeScale = 0;
        VictoriaP.Abrir();
    }
    public void PasaNivel()
    {
        //No tenemos niveles infinitos

        if(nivel< Niveles.Length)
        {
            nivel++;
            Time.timeScale = 1;
            IniciarNivel(nivel);
            VictoriaP.Cerrar();
        }
        else
        {
            print("Acaba el juego");
        }
        

    }
    void IniciarNivel(int nivel)
    {
        //Construye el siguiente nivel
        fondo.sprite = Fondos[nivel];
        Instantiate(Niveles[nivel], posicionNivel);
        numerodeLadrillos = GameObject.FindGameObjectsWithTag("Ladrillo").Length;
        //Reiniciar los puntos
        Puntos = 0;
        //Colocar todo en la posicion inicial.
        pala.transform.position = posicionInicialPala;
        bola.transform.parent = pala.transform;
        bola.transform.position = posicionIncialBola;
        if (bola.TryGetComponent<Rigidbody2D>(out rbBola))
        {
            rbBola.bodyType = RigidbodyType2D.Kinematic;
        }
        disparado = false;
    }
    
   
}
